Scratchpad
==========

This mini app uses HTML5 local storage API to create an online replacement for a simple Notepad/TextEdit type of application for Chromebooks. By default it creates one entry a day which allows you to implicitly save the history of your notes. They live locally in your browser's cache so content-wise anything goes.

Another HTML5 API (application cache) provides support for offline use so this essentially works as a local application rather than an online service.

Deployment
----------------

Copy the content to any Apache-powered server and enjoy. 
